% This function implement the Neural Network Ensemble (NNE) trained by NCL, for the Structural Motif data
% Learning parameter for NCL: Number of NN = 5
%                             Number of Hidden Neurons for each NN = 5
%                             Learning rate = 0.01
%                             Number of Epochs = 100
%                             lamda for NCL = 1
%
% data:       The data to be predicted using the NNE. It should be represented as a (No. of samples)-by-(No. of features matrix)
%             the class label should NOT be given in the matrix
% F_index:    the indices of the features used in the ensemble
% EnsOutput:  output of the ensemble
% Pred_Label: the class label of the data, predicted based on EnsOutput
% Example:    [Pred_Label,EnsOutput]=NNE4SCR(data,[1:1:10])
% NOTE:       For the model to work, the features of data must be generated in the exactly same way as that of the training data, and no pre-processing needs
%             to be done before feeding the data into this model.
% By Ke Tang 25/07/2008

function [Pred_Label,EnsOutput]=NNE_SCR(data,norm_flag,F_index)

d=size(data,2);
if nargin<3
   F_index=[1:1:d];
end

%%% Normalize the data %%%
load databound
for i=1:size(data,2)
    data(:,i)=(data(:,i)-lwb(F_index(i)))*2/(upb(F_index(i))-lwb(F_index(i)))-1;
end

%%% Apply the trained NN ensemble 
load NNEweights
for i=1:5
    NetOutput{i}=1./(1+exp(-1./(1+exp(-data*INNIH{i}(:,F_index)'))*INNHO{i}'));
end
EnsOutput=(NetOutput{1}+NetOutput{2}+NetOutput{3}+NetOutput{4}+NetOutput{5})/5;
Pred_Label=sign(EnsOutput(:,1)-EnsOutput(:,2));