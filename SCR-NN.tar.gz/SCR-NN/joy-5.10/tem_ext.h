#ifndef __tem_ext
#define __tem_ext

int assign_ext_features(int, int, ALI *, int *, SST *, PSA *, HBD *, TEM *);

int _ext_0 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_1 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_2 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_3 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_4 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_5 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_6 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_7 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_8 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_9 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_10 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_11 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_12 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_13 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_14 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_15 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_16 (char *, int, SST, PSA, HBD, TEM, int, int);
int _ext_17 (char *, int, SST, PSA, HBD, TEM, int, int);

extern char *ext_feature_name[];

#endif
