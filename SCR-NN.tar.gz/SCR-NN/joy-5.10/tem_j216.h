#ifndef __tem_j216
#define __tem_j216

int assign_j216_features(int, int, ALI *, int *, SST *, PSA *, HBD *, TEM *);

int _j216_0 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_1 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_2 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_3 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_4 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_5 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_6 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_7 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_8 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_9 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_10 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_11 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_12 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j216_13 (char *, int, SST, PSA, HBD, TEM, int, int);

extern char *j216_feature_name[];

#endif
