*******************************************************************************************************************
* DNA-Prot: Identification of DNA binding proteins from protein sequence information using Random   forest method *
* K. Krishna Kumar, Ganesan Pugalenthi, PN Suganthan   *                                                          *
*******************************************************************************************************************

How to use DNA-Prot
-------------------

DNA-Prot accepts one or more protein sequences in FASTA format. Please see example-input.seq for 
example.

Linux:
------

1. First install R package and  Random Forest Library in your computer. It can be downloaded from 
http://cran.r-project.org/.

2. Run DNA-Prot using the following command

perl DNA-prot.pl input-file-name

For example,

perl DNA-prot.pl example-input.seq

The prediction result will be stored in "Prediction-result" file (please see "example-output" file for example output.


Dataset:
--------
Training dataset    : Train-DNAbinding146.seq and Train-nonDNAbinding250.seq
Testing dataset     : Testset-DNAbinding92.seq and Testset-nonDNAbinding100.seq
Independent dataset1: Independent-set1-DNAbinding823.seq and Independent-set1-nonDNAbinding823.seq
Independent dataset2: Independent-set2-DNAbinding88.seq and Independent-set2-nonDNAbinding233.seq
