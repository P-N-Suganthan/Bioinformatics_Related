#!/usr/bin/perl
#######
$seqfile=$ARGV[0];
`./DNA-Prot-feature $seqfile > test.csv`;
`R --vanilla < Randomforest.r`;
open(SEQ,"$seqfile");
@seq=<SEQ>;
close SEQ;
chomp @seq;
$seqno=0;undef @sequence;undef @des;
foreach $seq(@seq)
{
	if($seq=~ />/)
	{
		$seqno++;
		$des[$seqno]=$seq;
	}
	else
	{
		$sequence[$i]=$sequence[$i].$seq;
	}
}
open(FL,"predicted_results.txt");
@res=<FL>;
close FL;
open(XX,">Prediction-result");
print XX"*********************************************************\n";
print XX"DNA-Prot prediction result\n";
print XX"*********************************************************\n\n";
print XX"Seqno        Prediction                     Description\n\n";
for($i=0;$i<=$#res;$i++)
{
	$k=$i+1;
	if($res[$i]==1)
	{
		$type="DNA-binding protein";

	}
	if($res[$i]==2)
	{
		$type="non DNA-binding protein";
	}
	printf XX"%-5s ##  %-30s  ##  %-s\n",$k,$type,$des[$i+1];

}
close XX;
`rm predicted_results.txt`;
