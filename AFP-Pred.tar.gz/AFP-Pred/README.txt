*******************************************************************************************************************
* AFP-Pred: Identification of antifreeze proteins from protein sequence information using Random   forest method  *
*******************************************************************************************************************

How to use AFP-pred
-------------------

AFP-pred accepts one or more protein sequences in FASTA format. Please see example-input.seq for 
example.

Linux:
------

1. First install R package and  Random Forest Library in your computer. It can be downloaded from 
http://cran.r-project.org/.

2. Run AFP-pred using the following command

./AFP-pred input-file-name

For example,

./AFP-pred example-input.seq

The prediction result will be stored in "Prediction-result" file.


Dataset:
--------
AFP.seq       --- 481  antifreeze proteins 
Non-AFP.seq   --- 9193 non-antifreeze proteins



Freatures119.txt  ---- List of 119 features
