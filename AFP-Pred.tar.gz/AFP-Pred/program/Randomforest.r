# Please install R-stastical Package and randomForest package on your system; you will get them on CRAN site.  
# Input format:.csv (comma seperated) files.
# The output will be the error rate , confusion matrix,Prediction Y labels for test dataset 
# Prediction_results.txt will store predicted y lables for test dataset
# Please keep all your input files in one folder


# Removes all previous matrices and variables from the R-System memory.
rm(list=ls())

# store the current directory in the variable 
initial.dir<-getwd()

# change to the new directory where the data file is stored
#setwd("C:/krishna/pugal/antifreeze proteins/newfea_300310/AFP-features/mRMR")

# load the necessary libraries 						
library(randomForest)
  
	    
testPP<-numeric()


# load the dataset
QdataTrain <- read.csv('train.csv',header = FALSE)
QdataTest <- read.csv('test.csv',header = FALSE)
			    
   QdataTrainX <- subset(QdataTrain,select=-V1)
QdataTrainY<-as.factor(QdataTrain$V1)   

QdataTestX <- subset(QdataTest,select=-V1)
QdataTestY<-as.factor(QdataTest$V1)


mdl <- randomForest(QdataTrainX, QdataTrainY)  # THIS WILL GENERATE MODEL 


# Training Error rate 
print(c(mdl$mtry,mdl$err.rate[mdl$ntree]),sep="\t",col.name=F)

#  CONFUSION MATRIX.for Training dataset...
print(mdl$confusion)


# Predicted Y labels for test dataset:
m<-predict(mdl,QdataTestX)

print(m)
  
# CONFUSION MATRIX.for Testing dataset
# Confusion Matrix will be as .. 
# TP FN
# FP TN

# and will be accesed as..
# t[1] t[3]
# t[2] t[4]


# Predicted Y labels for test dataset will store in file predicted_results.txt

outputFile <- "predicted_results.txt"
write.table(m ,file=outputFile,quote=FALSE,row.names=F,col.names=F,sep="\t")

t<-table(QdataTestY,m)
print(t)
