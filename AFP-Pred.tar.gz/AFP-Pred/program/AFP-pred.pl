#!/usr/bin/perl
#######
$seqfile=$ARGV[0];
#`./SPRED-feature $seqfile > test.csv`;
@ft=`./AFP-feature $seqfile`;
chomp @ft;
open(FT,">test.csv");
foreach $ft(@ft)
{
	if($ft=~ /Perl2Exe/){last;}
	print FT"$ft\n";
}
close FT;
`R --vanilla < Randomforest.r`;
open(SEQ,"$seqfile");
@seq=<SEQ>;
close SEQ;
chomp @seq;
$seqno=0;undef @sequence;undef @des;
foreach $seq(@seq)
{
	if($seq=~ />/)
	{
		$seqno++;
		$des[$seqno]=$seq;
	}
	else
	{
		$sequence[$i]=$sequence[$i].$seq;
	}
}
open(FL,"predicted_results.txt");
@res=<FL>;
close FL;
open(XX,">Prediction-result");
print XX"*********************************************************\n";
print XX"AFP-Pred prediction result\n";
print XX"*********************************************************\n\n";
print XX"Seqno        Prediction                     Description\n\n";
for($i=0;$i<=$#res;$i++)
{
	$k=$i+1;
	if($res[$i]==1)
	{
		$type="Antifreeze protein";

	}
	if($res[$i]==2)
	{
		$type="Non-antifreeze  protein";
	}
	printf XX"%-5s     %-30s      %-s\n",$k,$type,$des[$i+1];

}
close XX;
`rm predicted_results.txt seq1  seq1.horiz  seq1.ss  seq1.ss2`;
