#ifndef __tem_j4
#define __tem_j4

int assign_j4_features(int, int, ALI *, int *, SST *, PSA *, HBD *, TEM *);

int _j4_0 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_1 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_2 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_3 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_4 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_5 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_6 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_7 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_8 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_9 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_10 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_11 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_12 (char *, int, SST, PSA, HBD, TEM, int, int);
int _j4_13 (char *, int, SST, PSA, HBD, TEM, int, int);

extern char *j4_feature_name[];

#endif
