/*
 *
 * $Id:
 *
 * joy 5.0 release $Name:  $
 */
/****************************************************************************
* joy: A program for protein sequence-structure representation and analysis *
* Copyright (C) 1988-1997  John Overington                                  *
* Copyright (C) 1997-1999  Kenji Mizuguchi and Charlotte Deane              *
* Copyright (C) 1999-2000  Kenji Mizuguchi                                  *
*                                                                           *
* release.h                                                                 *
* Shows version info                                                        *
****************************************************************************/
#ifndef __release
#define __release

#define MAINVERSION "5"
#define SUBVERSION  "10"
#define UPDATE      "27 Mar 2003"

#endif
