#ifndef __tem_default
#define __tem_default

int assign_default_features(int, int, ALI *, int *, SST *, PSA *, HBD *, TEM *);

int _default_0 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_1 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_2 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_3 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_4 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_5 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_6 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_7 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_8 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_9 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_10 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_11 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_12 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_13 (char *, int, SST, PSA, HBD, TEM, int, int);
int _default_14 (char *, int, SST, PSA, HBD, TEM, int, int);

extern char *default_feature_name[];

#endif
