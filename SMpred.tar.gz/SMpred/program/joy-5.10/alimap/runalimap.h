/*
 * Runalimap Head file
 *
 */


/**************START**************/

#include "alimap.h"

#define runalimap_Name "runalimap.c"
#define RUNALIMAP
