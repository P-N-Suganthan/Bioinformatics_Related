      data DATE /'Wed Aug 16 12:24:47 EDT 2006'/
